// "use client";
// import React, { useEffect, useState } from "react";
// import { DiMongodb, DiNginx, DiNpm, DiPostgresql, DiVim } from "react-icons/di";
// import {
//   FaAws,
//   FaCss3,
//   FaDocker,
//   FaEnvelope,
//   FaGit,
//   FaGithub,
//   FaHtml5,
//   FaLinkedin,
//   FaLinux,
//   FaNodeJs,
//   FaPhone,
//   FaReact,
//   FaVuejs,
//   FaYarn,
// } from "react-icons/fa6";
// import {
//   RiFirebaseFill,
//   RiJavascriptFill,
//   RiNextjsFill,
//   RiTailwindCssFill,
// } from "react-icons/ri";
// import {
//   SiExpress,
//   SiJavascript,
//   SiKubuntu,
//   SiPm2,
//   SiPrettier,
//   SiTypescript,
//   SiVercel,
//   SiVscodium,
// } from "react-icons/si";
// import { VscCode } from "react-icons/vsc";

// // @ts-ignore
// import { Splide, SplideSlide } from "@splidejs/react-splide";
// import "@splidejs/react-splide/css";
// import { TbTerminal2 } from "react-icons/tb";

// const CONTACT_LINKS = [
//   {
//     name: "Email",
//     content: "naresh.khatri2345@gmail",
//     href: "mailto:naresh.khatri2345@gmail.com",
//     icon: <FaEnvelope height={"50px"} />,
//   },
//   {
//     name: "Phone",
//     content: "1234567890",
//     href: "tel:1234567890",
//     icon: <FaPhone height={"50px"} />,
//   },
//   {
//     name: "LinkedIn",
//     href: "https://www.linkedin.com/in/naresh-khatri/",
//     content: "/naresh-khatri",
//     icon: <FaLinkedin height={"50px"} />,
//   },
//   {
//     name: "GitHub",
//     href: "https://github.com/Amit-Chauhan",
//     content: "/naresh-khatri",
//     icon: <FaGithub height={"50px"} />,
//   },
// ];

// const TOOLS = [
//   {
//     name: "JavaScript",
//     content: "JavaScript is a high-level, interpreted programming language",
//     icon: <SiJavascript size={"50px"} color={"#f0db4f"} />,
//     color: "#f0db4f",
//   },
//   {
//     name: "TypeScript",
//     content: "TypeScript is a superset of JavaScript that compiles to plain JS",
//     icon: <SiTypescript size={"50px"} color={"#007acc"} />,
//     color: "#007acc",
//   },
//   {
//     name: "HTML",
//     content: "Next.js is a React framework for production",
//     icon: <FaHtml5 size={"50px"} color="#e34c26" />,
//     color: "#e34c26",
//   },
//   {
//     name: "CSS",
//     content: "Next.js is a React framework for production",
//     icon: <FaCss3 size={"50px"} color="#563d7c" />,
//     color: "#563d7c",
//   },
//   {
//     name: "Nodejs",
//     content: "Next.js is a React framework for production",
//     icon: <FaNodeJs size={"50px"} color="#6cc24a" />,
//     color: "#6cc24a",
//   },
//   {
//     name: "React.js",
//     content: "Next.js is a React framework for production",
//     icon: <FaReact size={"50px"} color="#61dafb" />,
//     color: "#61dafb",
//   },
//   {
//     name: "Docker",
//     content: "Next.js is a React framework for production",
//     icon: <FaDocker size={"50px"} color="#2496ed" />,
//     color: "#2496ed",
//   },
//   {
//     name: "NginX",
//     content: "Next.js is a React framework for production",
//     icon: <DiNginx size={"50px"} color="#008000" />,
//     color: "#008000",
//   },
//   {
//     name: "Vue.js",
//     content: "Next.js is a React framework for production",
//     icon: <FaVuejs size={"50px"} color="#41b883" />,
//     color: "#41b883",
//   },
//   {
//     name: "Express.js",
//     content: "Next.js is a React framework for production",
//     icon: <SiExpress size={"50px"} color="#fff" />,
//     color: "#000000",
//   },
//   {
//     name: "PostgreSQL",
//     content: "Next.js is a React framework for production",
//     icon: <DiPostgresql size={"50px"} color="#336791" />,
//     color: "#336791",
//   },
//   {
//     name: "MongoDB",
//     content: "Next.js is a React framework for production",
//     icon: <DiMongodb size={"50px"} color="#4db33d" />,
//     color: "#4db33d",
//   },
//   {
//     name: "Tailwind CSS",
//     content: "Next.js is a React framework for production",
//     icon: <RiTailwindCssFill size={"50px"} color="#06b6d4" />,
//     color: "#06b6d4",
//   },
//   {
//     name: "Firebase",
//     content: "Next.js is a React framework for production",
//     icon: <RiFirebaseFill size={"50px"} color="#FFCA28" />,
//     color: "#FFCA28",
//   },
//   {
//     name: "Git",
//     content: "Next.js is a React framework for production",
//     icon: <FaGit size={"50px"} color="#f05032" />,
//     color: "#f05032",
//   },
//   {
//     name: "GitHub",
//     content: "Next.js is a React framework for production",
//     icon: <FaGithub size={"50px"} color="#fff" />,
//     color: "#000000",
//   },
//   {
//     name: "VS Code",
//     content: "Next.js is a React framework for production",
//     icon: <SiVscodium size={"50px"} color="#007acc" />,
//     color: "#007acc",
//   },
//   {
//     name: "VIM",
//     content: "Next.js is a React framework for production",
//     icon: <DiVim size={"50px"} color="#fff" />,
//     color: "#000000",
//   },
//   {
//     name: "Prettier",
//     content: "Next.js is a React framework for production",
//     icon: <SiPrettier size={"50px"} color="#f7b93c" />,
//     color: "#f7b93c",
//   },
//   {
//     name: "NPM",
//     content: "Next.js is a React framework for production",
//     icon: <DiNpm size={"50px"} color="#CB3837" />,
//     color: "#CB3837",
//   },
//   {
//     name: "Yarn",
//     content: "Next.js is a React framework for production",
//     icon: <FaYarn size={"50px"} color="#2C8EBB" />,
//     color: "#2C8EBB",
//   },
//   {
//     name: "Vercel",
//     content: "Next.js is a React framework for production",
//     icon: <SiVercel size={"50px"} color="#fff" />,
//     color: "#000000",
//   },
//   {
//     name: "Linux",
//     content: "Next.js is a React framework for production",
//     icon: <FaLinux size={"50px"} color="#fff" />,
//     color: "#000000",
//   },
//   {
//     name: "Kubuntu",
//     content: "Next.js is a React framework for production",
//     // give me correct color for  kubuntu
//     icon: <SiKubuntu size={"50px"} color="#0077C4" />,
//     color: "#000000",
//   },
//   {
//     name: "Terminal",
//     content: "Next.js is a React framework for production",
//     icon: <TbTerminal2 size={"50px"} color="#fff" />,
//     color: "#000000",
//   },
//   {
//     name: "AWS",
//     content: "Next.js is a React framework for production",
//     icon: <FaAws size={"50px"} color="#3f51b5" />,
//     color: "#000000",
//   },
// ];

// function Page() {
//   const [toolsLoaded, setToolsLoaded] = useState(false);
//   useEffect(() => {
//     setToolsLoaded(true);
//   }, []);
//   return (
//     <div className="container mx-auto px-4 md:px-[50px] xl:px-[200px] text-zinc-300 pt-20 pb-20">
//       <div className="flex flex-col lg:flex-row gap-5">
//         <aside className="w-full md:basis-1/4">
//           <div
//             className="p-4 md:p-8 lg:p-10 rounded-2xl border-[.5px] border-zinc-600"
//             style={{
//               backdropFilter: "blur(2px)",
//             }}
//           >
//             <div className="flex flex-row lg:flex-col items-center">
//               <div className="flex justify-center items-center lg:w-full lg:aspect-square bg-zinc-800 rounded-xl lg:mb-5">
//                 <img
//                   className="rounded-full p-4 lg:p-10 w-[100px] md:w-[150px] lg:w-[200px] aspect-square  bg-zinc-800"
//                   alt="me"
//                   src="/assets/me.jpg"
//                 />
//               </div>
//               <div className="flex flex-col gap-3 lg:items-center ml-10 md:ml-20 lg:ml-0">
//                 <p className="text-center text-xl">Amit Chauhan</p>
//                 <div className="text-xs bg-zinc-700 w-fit px-3 py-1 rounded-full">
//                   Web Developer
//                 </div>
//               </div>
//             </div>
//             <div className="hidden lg:block">
//               <hr className="my-10 border-zinc-600" />
//               <ul className="flex flex-col gap-3">
//                 {CONTACT_LINKS.map((link) => (
//                   <li key={link.name}>
//                     <a
//                       className="flex items-center px-3 gap-3 w-full h-12 border-zinc-700 bg-zinc-800 hover:border-zinc-600 border-[.5px] rounded-md "
//                       href={link.href}
//                     >
//                       <div className="w-8">{link.icon}</div>
//                       <div className="flex flex-col">
//                         <div className="text-sm">{link.name}</div>
//                         <div className="text-xs text-zinc-500">
//                           {link.content}
//                         </div>
//                       </div>
//                     </a>
//                   </li>
//                 ))}
//               </ul>
//             </div>
//           </div>
//         </aside>
//         <main className="basis-3/4 w-[500px]">
//           <div
//             className="p-10 border-[.5px] rounded-md border-zinc-600"
//             style={{ backdropFilter: "blur(2px)" }}
//           >
//             <h1 className="text-3xl mb-10 lg:md-20">About me</h1>
//             <p className="mb-10 text-roboto">
//               Hey there! I&apos;m Amit, a Fullstack developer passionate about
//               creating meaningful digital experiences. With great in Web
//               development, I thrive on turning ideas into reality through coding
//               and design. My journey began with a fascination for technology and
//               a drive to make a positive impact.
//             </p>
//             <p className="mb-10">
//               When I&apos;m not coding, you can find me [Your
//               Interests/Hobbies], exploring new technologies, or sipping coffee
//               while brainstorming my next project.
//             </p>
//             <h1 className="text-3xl mb-10 lg:md-20">Stuff I use</h1>
//             <div className="mb-5">
//               {!toolsLoaded ? (
//                 <p className="h-[100px]"></p>
//               ) : (
//                 <Splide
//                   options={{
//                     type: "loop",
//                     interval: 2000,
//                     autoplay: true,
//                     pagination: false,
//                     speed: 2000,
//                     perPage: 5,
//                     perMove: 1,
//                     rewind: true,
//                     easing: "cubic-bezier(0.25, 1, 0.5, 1)",
//                     arrows: false,
//                   }}
//                   aria-label="My Favorite Images"
//                 >
//                   {TOOLS.reverse().map((tool) => (
//                     <SplideSlide key={tool.name}>
//                       <div
//                         key={tool.name}
//                         className="w-fit p-2 border-[.5px] border-zinc-600 rounded-md"
//                       >
//                         {tool.icon}
//                       </div>
//                     </SplideSlide>
//                   ))}
//                 </Splide>
//               )}
//             </div>
//             {/* <div className="">
//               <Splide
//                 options={{
//                   type: "loop",
//                   interval: 2000,
//                   autoplay: true,
//                   pagination: false,
//                   speed: 3000,
//                   perPage: 5,
//                   perMove: 1,
//                   rewind: true,
//                   easing: "cubic-bezier(0.25, 1, 0.5, 1)",
//                   arrows: false,
//                 }}
//                 aria-label="My Favorite Images"
//               >
//                 {TOOLS.map((tool) => (
//                   <SplideSlide key={tool.name}>
//                     <div
//                       key={tool.name}
//                       className="w-fit p-2 border-[.5px] border-zinc-600 rounded-md"
//                     >
//                       {tool.icon}
//                     </div>
//                   </SplideSlide>
//                 ))}
//               </Splide>
//             </div> */}
//           </div>
//         </main>
//       </div>
//     </div>
//   );
// }

// export default Page;

















"use client";
import React, { useEffect, useState } from "react";
import { DiMongodb, DiNginx, DiNpm, DiPostgresql, DiVim } from "react-icons/di";
import {
  FaAws,
  FaCss3,
  FaDocker,
  FaEnvelope,
  FaGit,
  FaGithub,
  FaHtml5,
  FaLinkedin,
  FaLinux,
  FaNodeJs,
  FaPhone,
  FaReact,
  FaVuejs,
  FaYarn,
} from "react-icons/fa6";
import {
  RiFirebaseFill,
  RiTailwindCssFill,
} from "react-icons/ri";
import {
  SiExpress,
  SiKubuntu,
  SiPm2,
  SiPrettier,
  SiTypescript,
  SiVercel,
  SiVscodium,
} from "react-icons/si";
import { VscCode } from "react-icons/vsc";
import { TbTerminal2 } from "react-icons/tb";

// @ts-ignore
import { Splide, SplideSlide } from "@splidejs/react-splide";
import "@splidejs/react-splide/css";

const CONTACT_LINKS = [
  {
    name: "Email",
    content: "ak6013348@gmail.com",
    href: "mailto:ak6013348@gmail.com",
    icon: <FaEnvelope />,
  },
  {
    name: "Phone",
    content: "+91 7717388828",
    href: "tel:+917717388828",
    icon: <FaPhone />,
  },
  {
    name: "GitHub",
    href: "https://github.com/Amit-bott",
    content: "/Amit-bott",
    icon: <FaGithub />,
  },
];

const TOOLS = [
  { name: "Python", icon: <VscCode size={50} color="#3776AB" /> },
  { name: "TypeScript", icon: <SiTypescript size={50} color="#007acc" /> },
  { name: "HTML", icon: <FaHtml5 size={50} color="#e34c26" /> },
  { name: "CSS", icon: <FaCss3 size={50} color="#264de4" /> },
  { name: "React", icon: <FaReact size={50} color="#61dafb" /> },
  { name: "Node.js", icon: <FaNodeJs size={50} color="#6cc24a" /> },
  { name: "MongoDB", icon: <DiMongodb size={50} color="#4db33d" /> },
  { name: "PostgreSQL", icon: <DiPostgresql size={50} color="#336791" /> },
  { name: "Docker", icon: <FaDocker size={50} color="#2496ed" /> },
  { name: "Nginx", icon: <DiNginx size={50} color="#009639" /> },
  { name: "Tailwind", icon: <RiTailwindCssFill size={50} color="#06b6d4" /> },
  { name: "Git", icon: <FaGit size={50} color="#f05032" /> },
  { name: "GitHub", icon: <FaGithub size={50} /> },
  { name: "Vercel", icon: <SiVercel size={50} /> },
  { name: "Linux", icon: <FaLinux size={50} /> },
  { name: "Kubuntu", icon: <SiKubuntu size={50} color="#0077C4" /> },
  { name: "Terminal", icon: <TbTerminal2 size={50} /> },
  { name: "AWS", icon: <FaAws size={50} color="#FF9900" /> },
];

export default function Page() {
  const [loaded, setLoaded] = useState(false);
  useEffect(() => setLoaded(true), []);

  return (
    <div className="container mx-auto px-6 xl:px-48 text-zinc-300 py-20">
      <div className="flex flex-col lg:flex-row gap-6">
        {/* SIDEBAR */}
        <aside className="lg:w-1/4">
          <div className="p-6 rounded-2xl border border-zinc-700 backdrop-blur">
            <div className="flex flex-col items-center">
              <img
                src="/assets/me.jpg"
                alt="Amit Chouhan"
                className="w-40 h-40 rounded-full bg-zinc-800 p-4"
              />
              <h2 className="text-xl mt-4">Amit Chouhan</h2>
              <span className="text-xs bg-zinc-700 px-3 py-1 rounded-full mt-2">
                Python • DS • AI/ML/DL • Software Engineer
              </span>

              <a
                href="/resume/Amit_Chouhan_Resume.pdf"
                target="_blank"
                className="mt-5 w-full text-center py-2 rounded-lg bg-white text-black font-semibold"
              >
                Download Resume
              </a>
            </div>

            <hr className="my-6 border-zinc-700" />

            <ul className="flex flex-col gap-3">
              {CONTACT_LINKS.map((c) => (
                <li key={c.name}>
                  <a
                    href={c.href}
                    className="flex gap-3 items-center p-3 rounded-md bg-zinc-800 border border-zinc-700 hover:border-zinc-500"
                  >
                    {c.icon}
                    <div>
                      <p className="text-sm">{c.name}</p>
                      <p className="text-xs text-zinc-500">{c.content}</p>
                    </div>
                  </a>
                </li>
              ))}
            </ul>
          </div>
        </aside>

        {/* MAIN */}
        <main className="lg:w-3/4">
          <div className="p-10 border border-zinc-700 rounded-xl backdrop-blur">
            <h1 className="text-3xl mb-6">About Me</h1>
            <p className="mb-6">
              I’m Amit Chouhan, a motivated Python & Data Science enthusiast with
              hands-on experience in Machine Learning, Data Analysis, and basic
              web development. I have completed a 6-month professional training
              in Python, Data Science, AI, ML & DL at Sonalika.
            </p>
            <p className="mb-10">
              I enjoy building intelligent solutions, exploring new technologies,
              and continuously improving my skills. When I’m not coding, you’ll
              find me gaming 🎮 or learning something new.
            </p>

            <h2 className="text-3xl mb-6">Tools & Technologies</h2>

            {loaded && (
              <Splide
                options={{
                  type: "loop",
                  autoplay: true,
                  interval: 2000,
                  perPage: 6,
                  arrows: false,
                  pagination: false,
                  speed: 1500,
                }}
              >
                {TOOLS.map((tool) => (
                  <SplideSlide key={tool.name}>
                    <div className="p-3 border border-zinc-700 rounded-md w-fit">
                      {tool.icon}
                    </div>
                  </SplideSlide>
                ))}
              </Splide>
            )}
          </div>
        </main>
      </div>
    </div>
  );
}
